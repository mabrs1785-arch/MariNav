rootProject.name = "MariNav"
include(":app")
